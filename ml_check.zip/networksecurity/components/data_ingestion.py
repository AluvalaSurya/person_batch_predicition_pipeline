# from networksecurity.exception.exception import NetworkSecurityException
# from networksecurity.logger.logger import logging

# #configuration for Data ingestion config
# from networksecurity.entity.config_entity import DataIngestionConfig
# from networksecurity.entity.artifact_entity import DataIngestionArtifact

# import os
# import sys
# import numpy as np
# import pandas as pd
# import pymongo
# from typing import List
# from sklearn.model_selection import train_test_split

# from dotenv import load_dotenv
# load_dotenv()

# MONGO_DB_URL = os.getenv("MONGO_DB_URL")

# class DataIngestion:
#     def __init__(self,data_ingestion_config:DataIngestionConfig):
#         try:
#             self.data_ingestion_config = data_ingestion_config
#         except Exception as e:
#             raise NetworkSecurityException(e,sys)
        
#     def export_collection_as_dataframe(self):
#         """
#         Read data from mongodb
#         """
#         try:
#             database_name = self.data_ingestion_config.database_name
#             collection_name = self.data_ingestion_config.collection_name
#             self.mongo_client = pymongo.MongoClient(MONGO_DB_URL)
#             collection = self.mongo_client[database_name][collection_name]

#             df = pd.DataFrame(list(collection.find()))
#             if "_id" in df.columns.to_list():
#                 df = df.drop(columns=["_id"])
            
#             df.replace({"na":np.nan},inplace=True)

#             # Convert timestamp to datetime
#             df["timestamp"] = pd.to_datetime(df["timestamp"])

#             # Create minutes column
#             df["minutes"] = (
#                 df["timestamp"].dt.hour * 60
#                 + df["timestamp"].dt.minute
#             )
#             return df
        
#         except Exception as e:
#             raise NetworkSecurityException(e,sys)
    
#     def export_data_into_feature_store(self,dataframe:pd.DataFrame):
#         try:
#             feature_store_file_path = self.data_ingestion_config.feature_store_file_path
#             #creating folder
#             dir_path = os.path.dirname(feature_store_file_path)
#             os.makedirs(dir_path,exist_ok=True)
#             dataframe.to_csv(feature_store_file_path,index=False,header=True)
#             return dataframe
#         except Exception as e:
#             raise NetworkSecurityException(e,sys)   

    
#     # def split_data_as_train_test(self,dataframe:pd.DataFrame):
#     #     try:
#     #         train_set,test_set = train_test_split(
#     #             dataframe,test_size = self.data_ingestion_config.train_test_split_ratio
#     #         )
#     #         logging.info("Performed train test split on dataframe")
            
#     #         dir_path = os.path.dirname(self.data_ingestion_config.training_file_path)
#     #         os.makedirs(dir_path,exist_ok=True)

#     #         logging.info("Exporting train and test file path")
#     #         train_set.to_csv(
#     #             self.data_ingestion_config.training_file_path,index=False,header = True
#     #         )
#     #         test_set.to_csv(
#     #             self.data_ingestion_config.testing_file_path,index=False,header = True
#     #         )
        
#     #     except Exception as e:
#     #         raise NetworkSecurityException(e,sys) 


#     def split_data_as_train_test(self, dataframe: pd.DataFrame):

#         try:

#             train_df = pd.DataFrame()
#             test_df = pd.DataFrame()

#             # Sort entire dataframe
#             dataframe = dataframe.sort_values(by="timestamp")

#             # Split within each person
#             for dname, group in dataframe.groupby("dname"):
                
#                 train_size = int(len(group) * self.data_ingestion_config.train_test_split_ratio)

#                 train_group = group.iloc[:train_size]
#                 test_group = group.iloc[train_size:]

#                 train_df = pd.concat([train_df, train_group])
#                 test_df = pd.concat([test_df, test_group])

#             logging.info("Performed behavior-based train test split")

#             dir_path = os.path.dirname(
#                 self.data_ingestion_config.training_file_path
#             )

#             os.makedirs(dir_path, exist_ok=True)

#             train_df.to_csv(
#                 self.data_ingestion_config.training_file_path,
#                 index=False,
#                 header=True
#             )

#             test_df.to_csv(
#                 self.data_ingestion_config.testing_file_path,
#                 index=False,
#                 header=True
#             )

#         except Exception as e:
#             raise NetworkSecurityException(e, sys)
        
#         logging.info("Exported train and test file path")
#         logging.info("Exited split_data_as_train_test method of Data_Ingestion class")


          
#     #final function
#     def initiate_data_ingestion(self):
#         try:
#             dataframe = self.export_collection_as_dataframe()
#             dataframe = self.export_data_into_feature_store(dataframe)
#             self.split_data_as_train_test(dataframe)
#             dataingestionartifact = DataIngestionArtifact(trained_file_path = self.data_ingestion_config.training_file_path,
#                                                           test_file_path = self.data_ingestion_config.testing_file_path)
            
#             return dataingestionartifact
        
#         except Exception as e:
#             raise NetworkSecurityException(e,sys)


from networksecurity.exception.exception import NetworkSecurityException
from networksecurity.logger.logger import logging

from networksecurity.entity.config_entity import DataIngestionConfig
from networksecurity.entity.artifact_entity import DataIngestionArtifact

import os
import sys
import numpy as np
import pandas as pd
import pymongo

from dotenv import load_dotenv

load_dotenv()

MONGO_DB_URL = os.getenv("MONGO_DB_URL")


class DataIngestion:
    def __init__(self, data_ingestion_config: DataIngestionConfig):
        try:
            self.data_ingestion_config = data_ingestion_config
        except Exception as e:
            raise NetworkSecurityException(e, sys)

    def export_collection_as_dataframe(self):

        """
        Read data from MongoDB
        """

        try:
            database_name = self.data_ingestion_config.database_name
            collection_name = self.data_ingestion_config.collection_name

            self.mongo_client = pymongo.MongoClient(MONGO_DB_URL)
            collection = self.mongo_client[database_name][collection_name]

            df = pd.DataFrame(list(collection.find()))

            if "_id" in df.columns:
                df = df.drop(columns=["_id"])

            df.replace({"na": np.nan}, inplace=True)

            logging.info("MongoDB data exported successfully")

            return df

        except Exception as e:
            raise NetworkSecurityException(e, sys)

    def export_data_into_feature_store(self, dataframe: pd.DataFrame):

        try:
            feature_store_file_path = (self.data_ingestion_config.feature_store_file_path)

            dir_path = os.path.dirname(feature_store_file_path)
            os.makedirs(dir_path, exist_ok=True)

            dataframe.to_csv(feature_store_file_path,index=False,header=True)
            logging.info("Feature store file saved")

            return dataframe

        except Exception as e:
            raise NetworkSecurityException(e, sys)

    def initiate_data_ingestion(self):

        try:
            dataframe = self.export_collection_as_dataframe()
            dataframe = self.export_data_into_feature_store(dataframe)

            data_ingestion_artifact = DataIngestionArtifact(
                trained_file_path=self.data_ingestion_config.feature_store_file_path,
                test_file_path=self.data_ingestion_config.feature_store_file_path
            )
            return data_ingestion_artifact

        except Exception as e:
            raise NetworkSecurityException(e, sys)